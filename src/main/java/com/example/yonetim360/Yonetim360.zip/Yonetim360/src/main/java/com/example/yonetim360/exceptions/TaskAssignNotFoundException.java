package com.example.yonetim360.exceptions;

public class TaskAssignNotFoundException extends RuntimeException{

    public TaskAssignNotFoundException(String message){
        super(message);
    }
}
