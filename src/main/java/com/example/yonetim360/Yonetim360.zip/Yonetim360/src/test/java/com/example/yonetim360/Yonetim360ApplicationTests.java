package com.example.yonetim360;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Yonetim360ApplicationTests {

    @Test
    void contextLoads() {
    }

}
