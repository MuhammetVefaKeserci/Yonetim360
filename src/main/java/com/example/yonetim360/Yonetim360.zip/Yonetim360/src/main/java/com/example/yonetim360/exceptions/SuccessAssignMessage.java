package com.example.yonetim360.exceptions;

public class SuccessAssignMessage extends RuntimeException{

}
